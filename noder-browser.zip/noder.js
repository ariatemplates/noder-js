/*
 * Noder-js 1.0.0-rc0 - 13 Jun 2013
 * https://github.com/ariatemplates/noder
 *
 * Copyright 2009-2013 Amadeus s.a.s.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/*jshint undef:true*/
(function(global,callEval){
'use strict';
var internalRequire;
var internalDefine;

(function() {
    // This function defines a very small and simple internal module system for the loader itself.
    // It does not support circular dependencies and supposes all the modules are defined from the beginning.
    var modulesDef = {};
    var modules = {};

    internalRequire = function(moduleIndex) {
        var res = modules[moduleIndex];
        if (!res) {
            res = modulesDef[moduleIndex];
            if (res) {
                var module = {
                    exports: {}
                };
                res(module);
                res = modules[moduleIndex] = module.exports;
                modulesDef[moduleIndex] = null; // release some memory if possible
            } else {
                throw new Error("Missing internal module: " + moduleIndex);
            }
        }
        return res;
    };
    internalDefine = function(moduleIndex, moduleDef) {
        modulesDef[moduleIndex] = moduleDef;
    };
})();
internalDefine(1 /* main */, function (module) {

var Context = internalRequire(2 /* context */);
var defaultConfig = internalRequire(3 /* defaultConfig */);

Context.expose('noder-js/promise.js', internalRequire(4 /* promise */));
Context.expose('noder-js/context.js', internalRequire(2 /* context */));
Context.expose('noder-js/findRequires.js', internalRequire(5 /* findRequires */));
Context.expose('noder-js/jsEval.js', internalRequire(6 /* jsEval */));
Context.expose('noder-js/request.js', internalRequire(7 /* request */));

module.exports = Context.createContext(defaultConfig);


});

internalDefine(2 /* context */, function (module) {

var promise = internalRequire(4 /* promise */);
var Loader = internalRequire(8 /* loader */);
var Resolver = internalRequire(9 /* resolver */);
var execScripts = internalRequire(10 /* execScripts */);
var typeUtils = internalRequire(11 /* type */);
var noderError = internalRequire(12 /* noderError */);
var dirname = internalRequire(13 /* path */).dirname;
var jsEval = internalRequire(6 /* jsEval */);
var findRequires = internalRequire(5 /* findRequires */);
var noderPropertiesKey = "_noder";

var PROPERTY_DEFINITION = 0;
var PROPERTY_DEPENDENCIES = 1;
var PROPERTY_EXECUTING = 2;
var PROPERTY_PRELOADING = 3;
var PROPERTY_LOADING_DEFINITION = 4;

var bind = function(fn, scope) {
    return function() {
        return fn.apply(scope, arguments);
    };
};

var bind1 = function(fn, scope, paramBind) {
    return function(param) {
        return fn.call(scope, paramBind, param);
    };
};

var Module = function(context, filename) {
    if (filename) {
        this.dirname = dirname(filename);
    } else {
        this.dirname = filename = '.';
    }
    this[noderPropertiesKey] = {};
    this.filename = filename;
    this.id = filename;
    this.require = bind1(context.moduleRequire, context, this);
    this.require.resolve = bind1(context.moduleResolve, context, this);
    this.require.cache = context.cache;
    this.parent = null;
    this.children = [];
    this.preloaded = false;
    this.loaded = false;
    this.exports = {};
};

var getModuleProperty = function(module, property) {
    return module[noderPropertiesKey][property];
};

var setModuleProperty = function(module, property, value) {
    module[noderPropertiesKey][property] = value;
    return value;
};

var start = function(context) {
    var config = context.config;
    var actions = promise.done;

    if (!("scriptsType" in config)) {
        config.scriptsType = config.varName;
    }
    var scriptsType = config.scriptsType;
    if (scriptsType) {
        actions = actions.then(function() {
            return execScripts(context, scriptsType);
        });
    }

    var main = config.main;
    actions = actions.then(main ? function() {
        return context.execModuleCall(main);
    } : promise.empty /* if there is no main module, an empty parameter should be passed to onstart */ );

    actions = actions.then(config.onstart);

    return actions.always(function() {
        context = null;
        config = null;
        actions = null;
    });
};

var Context = function(config) {
    config = config || {};
    this.config = config;
    this.cache = {};

    this.resolver = new Resolver(this);
    this.loader = new Loader(this);

    var rootModule = new Module(this);
    rootModule.preloaded = true;
    rootModule.loaded = true;
    rootModule.define = this.define = bind(this.define, this);
    rootModule.asyncRequire = bind1(this.moduleAsyncRequire, this, rootModule);
    rootModule.execute = bind(this.jsModuleExecute, this);
    rootModule.createContext = Context.createContext;
    this.rootModule = rootModule;

    var globalVarName = config.varName;
    if (globalVarName) {
        global[globalVarName] = rootModule;
    }

    start(this).end();
};

var contextProto = Context.prototype = {};

// Preloading a module means making it ready to be executed (loading its definition and preloading its
// dependencies)
contextProto.modulePreload = function(module, parent) {
    if (module.preloaded) {
        return promise.done;
    }
    var preloading = getModuleProperty(module, PROPERTY_PRELOADING);
    if (preloading) {
        // If we get here, it may be because of a circular dependency
        // check it here:
        while (parent) {
            if (parent === module) {
                return promise.done;
            }
            parent = parent.parent;
        }
        return preloading;
    }
    var self = this;
    if (parent && parent.id != '.') {
        module.parent = parent;
        module.require.main = parent.require.main;
        parent.children.push(module);
    } else {
        module.require.main = module;
    }
    return setModuleProperty(module, PROPERTY_PRELOADING, self.moduleLoadDefinition(module).then(function() {
        return self.modulePreloadDependencies(module, getModuleProperty(module, PROPERTY_DEPENDENCIES));
    }).then(function() {
        module.preloaded = true;
        setModuleProperty(module, PROPERTY_PRELOADING, false);
    }, function(error) {
        throw noderError("modulePreload", [module], error);
    }).always(function() {
        // clean up
        module = null;
        self = null;
        parent = null;
    }));
};

contextProto.moduleLoadDefinition = function(module) {
    if (getModuleProperty(module, PROPERTY_DEFINITION)) {
        return promise.done;
    }
    var res = getModuleProperty(module, PROPERTY_LOADING_DEFINITION);
    if (!res) {
        // store the promise so that it can be resolved when the define method is called:
        res = setModuleProperty(module, PROPERTY_LOADING_DEFINITION, promise());
        var filename = module.filename;
        if (this.builtinModules.hasOwnProperty(filename)) {
            this.moduleDefine(module, [], this.builtinModules[filename](this));
        } else {
            this.loader.moduleLoad(module).always(function(error) {
                // if reaching this, and if res is still pending, then it means the module was not found where expected
                if (res.isPending()) {
                    res.reject(noderError("moduleLoadDefinition", [module], error));
                }
                res = null;
            });
        }
    }
    return res;
};

contextProto.modulePreloadDependencies = function(module, modules) {
    var promises = [];
    for (var i = 0, l = modules.length; i < l; i++) {
        promises.push(this.modulePreload(this.getModule(this.moduleResolve(module, modules[i])), module));
    }
    return promise.when(promises);
};

contextProto.moduleExecuteSync = function(module) {
    if (module.loaded || getModuleProperty(module, PROPERTY_EXECUTING)) { /* this.executing is true only in the case of a circular dependency */
        return module.exports;
    }
    if (!module.preloaded) {
        throw noderError("notPreloaded", [module]);
    }
    var exports = module.exports;
    setModuleProperty(module, PROPERTY_EXECUTING, true);
    try {
        getModuleProperty(module, PROPERTY_DEFINITION).call(exports, module, global);
        setModuleProperty(module, PROPERTY_DEFINITION, null);
        setModuleProperty(module, PROPERTY_DEPENDENCIES, null);
        module.loaded = true;
        return module.exports;
    } finally {
        setModuleProperty(module, PROPERTY_EXECUTING, false);
    }
};

contextProto.moduleResolve = function(module, id) {
    return this.resolver.moduleResolve(module, id);
};

contextProto.moduleRequire = function(module, id) {
    return this.moduleExecuteSync(this.getModule(this.moduleResolve(module, id)));
};

contextProto.getModule = function(moduleFilename) {
    if (!moduleFilename) {
        // anonymous module
        return new Module(this);
    }
    var res = this.cache[moduleFilename];
    if (!res) {
        this.cache[moduleFilename] = res = new Module(this, moduleFilename);
    }
    return res;
};

contextProto.define = function(moduleFilename, dependencies, body) {
    this.moduleDefine(this.getModule(moduleFilename), dependencies, body);
};

contextProto.moduleDefine = function(module, dependencies, body) {
    if (!getModuleProperty(module, PROPERTY_DEFINITION)) {
        // do not override an existing definition
        setModuleProperty(module, PROPERTY_DEFINITION, body);
        setModuleProperty(module, PROPERTY_DEPENDENCIES, dependencies);
        var loadingDefinition = getModuleProperty(module, PROPERTY_LOADING_DEFINITION);
        if (loadingDefinition) {
            setModuleProperty(module, PROPERTY_LOADING_DEFINITION, false);
            loadingDefinition.resolve();
        }
    }
    return module;
};

contextProto.moduleExecute = function(module) {
    var self = this;
    return self.modulePreload(module).then(function() {
        return self.moduleExecuteSync(module);
    }).always(function() {
        self = null;
        module = null;
    });
};

contextProto.moduleAsyncRequire = function(module, id) {
    if (typeUtils.isArray(id)) {
        return this.modulePreloadDependencies(module, id);
    } else {
        return this.moduleRequire(module, id);
    }
};

contextProto.jsModuleDefine = function(jsCode, moduleFilename, url, lineDiff) {
    var dependencies = findRequires(jsCode);
    var body = this.jsModuleEval(jsCode, url || moduleFilename, lineDiff);
    return this.moduleDefine(this.getModule(moduleFilename), dependencies, body);
};

contextProto.jsModuleExecute = function(jsCode, moduleFilename, url) {
    return this.moduleExecute(this.jsModuleDefine(jsCode, moduleFilename, url));
};

contextProto.jsModuleEval = function(jsCode, url, lineDiff) {
    var code = ['(function(module, global){\nvar require = module.require, exports = module.exports, __filename = module.filename, __dirname = module.dirname;\n\n', jsCode, '\n\n})'];
    return jsEval(code.join(''), url, (lineDiff || 0) + 3 /* we are adding 3 lines compared to url */ );
};

contextProto.execModuleCall = function(moduleFilename) {
    return this.moduleExecute(this.getModule(this.moduleResolve(this.rootModule, moduleFilename)));
};

contextProto.builtinModules = {
    "noder-js/asyncRequire.js": function(context) {
        return function(module) {
            module.exports = {
                create: function(module) {
                    return function(id) {
                        return context.moduleAsyncRequire(module, id);
                    };
                }
            };
        };
    }
};

contextProto.Context = Context;

Context.createContext = function(cfg) {
    return (new Context(cfg)).rootModule;
};

Context.expose = function(name, exports) {
    var body = function(module) {
        module.exports = exports;
    };
    contextProto.builtinModules[name] = function() {
        return body;
    };
};

module.exports = Context;


});

internalDefine(3 /* defaultConfig */, function (module) {

var config = internalRequire(14 /* scriptConfig */);
if (!("varName" in config)) {
    config.varName = "noder";
}
module.exports = config;


});

internalDefine(4 /* promise */, function (module) {

var extend = internalRequire(15 /* extend */);
var isFunction = internalRequire(11 /* type */).isFunction;
var callListeners = internalRequire(16 /* callListeners */);
var uncaughtError = internalRequire(17 /* uncaughtError */);

var concat = Array.prototype.concat;

var PENDING_STATE = "pending";

var propagateResults = function(callback, deferred) {
    return function() {
        try {
            // the try...catch here is essential for a correct promises implementation
            // see: https://gist.github.com/3889970
            var res = callback.apply(null, arguments);
            if (res && isFunction(res.then)) {
                res.then(deferred.resolve, deferred.reject);
            } else {
                deferred.resolve(res);
            }
        } catch (e) {
            deferred.reject(e);
        } finally {
            callback = null;
            deferred = null;
        }
    };
};

var createPromise = function() {
    var deferred = {};
    var state = PENDING_STATE;
    var result = null;
    var listeners = {};

    var listenersMethods = function(newState) {
        var addCb = function() {
            var curListeners;
            if (state === PENDING_STATE) {
                curListeners = listeners[newState] || [];
                listeners[newState] = concat.apply(curListeners, arguments);
            } else if (state === newState) {
                curListeners = concat.apply([], arguments);
                callListeners(curListeners, result);
            }
            return this;
        };
        var fire = function() {
            if (state !== PENDING_STATE) {
                return;
            }
            result = arguments;
            state = newState;
            var myListeners = listeners[newState];
            listeners = null;
            callListeners(myListeners, result);
        };
        return [addCb, fire];
    };
    var done = listenersMethods("resolved");
    var fail = listenersMethods("rejected");

    var promise = {
        state: function() {
            return state;
        },
        isPending: function() {
            return state == PENDING_STATE;
        },
        always: function() {
            deferred.done.apply(deferred, arguments).fail.apply(deferred, arguments);
            return this;
        },
        done: done[0 /*addCb*/ ],
        fail: fail[0 /*addCb*/ ],
        then: function(done, fail) {
            var res = createPromise();
            deferred.done(isFunction(done) ? propagateResults(done, res) : res.resolve);
            deferred.fail(isFunction(fail) ? propagateResults(fail, res) : res.reject);
            return res.promise();
        },
        promise: function(obj) {
            return obj ? extend(obj, promise) : promise;
        },
        end: function() {
            return deferred.then(createPromise.empty, uncaughtError);
        }
    };
    deferred.resolve = done[1 /*fire*/ ];
    deferred.reject = fail[1 /*fire*/ ];
    promise.promise(deferred);

    return deferred;
};

var done = createPromise();
done.resolve();

createPromise.done = done.promise();

createPromise.empty = function() {};

createPromise.noop = function() {
    return done;
};

var countDown = function(state, index) {
    state.counter++;
    return function(result) {
        if (!state) {
            // already called with this index
            return;
        }
        var array = state.array;
        array[index] = result;
        state.counter--;
        if (!state.counter) {
            var promise = state.promise;
            // clean closure variables:
            state.array = null;
            state.promise = null;
            promise.resolve.apply(promise, array);
        }
        // prevent another call with the same index
        state = null;
    };
};

createPromise.when = function() {
    var array = concat.apply([], arguments);
    var promise = createPromise(),
        state, reject;
    for (var i = 0, l = array.length; i < l; i++) {
        var curItem = array[i];
        if (curItem && isFunction(curItem.then)) {
            if (!state) {
                state = {
                    promise: promise,
                    counter: 0,
                    array: array
                };
                reject = promise.reject;
            }
            curItem.then(countDown(state, i), reject);
        }
    }
    if (!state) {
        promise.resolve.apply(promise, array);
    }
    return promise.promise();
};

module.exports = createPromise;


});

internalDefine(5 /* findRequires */, function (module) {

var splitRegExp = /(?=[\/'"]|\brequire\s*\()/;
var requireRegExp = /^require\s*\(\s*$/;
var endOfLineRegExp = /[\r\n]/;
var quoteRegExp = /^['"]$/;
var operatorRegExp = /^[!%&\(*+,\-\/:;<=>?\[\^]$/;
var firstNonSpaceCharRegExp = /^\s*(\S)/;
var lastNonSpaceCharRegExp = /(\S)\s*$/;

var isEscaped = function(string) {
    var escaped = false;
    var index = string.length - 1;
    while (index >= 0 && string.charAt(index) == '\\') {
        index--;
        escaped = !escaped;
    }
    return escaped;
};

var getLastNonSpaceChar = function(array, i) {
    for (; i >= 0; i--) {
        var curItem = array[i];
        if (lastNonSpaceCharRegExp.test(curItem)) {
            return RegExp.$1;
        }
    }
    return "";
};

var checkRequireScope = function(array, i) {
    return i === 0 || getLastNonSpaceChar(array, i - 1) != ".";
};

var isRegExp = function(array, i) {
    return i === 0 || operatorRegExp.test(getLastNonSpaceChar(array, i - 1));
};

var findEndOfStringOrRegExp = function(array, i) {
    var expectedEnd = array[i].charAt(0);
    i++;
    for (var l = array.length; i < l; i++) {
        var item = array[i].charAt(0);
        if (item === expectedEnd) {
            if (!isEscaped(array[i - 1])) {
                return i;
            }
        }
    }
    throw new Error("Unterminated string or regexp.");
};

var getStringContent = function(array, begin, end) {
    // The string is supposed not to contain any special things such as: \n \r \t \' \"
    return array.slice(begin, end).join('').substring(1);
};

var findEndOfSlashComment = function(array, beginIndex) {
    for (var i = beginIndex + 1, l = array.length; i < l; i++) {
        var curItem = array[i];
        var index = curItem.search(endOfLineRegExp);
        if (index > -1) {
            array[i] = curItem.substring(index);
            array.splice(beginIndex, i - beginIndex);
            return beginIndex;
        }
    }
    return i;
};

var findEndOfStarComment = function(array, beginIndex) {
    var i = beginIndex + 1;
    if (array[beginIndex] == "/*") {
        i++;
    }
    var curItem = array[i - 1];
    for (var l = array.length; i < l; i++) {
        var prevItem = curItem;
        curItem = array[i];
        if (prevItem.charAt(prevItem.length - 1) == '*' && curItem.charAt(0) == '/') {
            array.splice(beginIndex, i - beginIndex);
            array[beginIndex] = curItem.substring(1);
            return beginIndex;
        }
    }
    return i;
};

module.exports = function(source) {
    var ids = [];
    var i = 0;
    var array = source.split(splitRegExp);
    /*
     * inRequireState variable:
     * 0 : outside of any useful require
     * 1 : just reached require
     * 2 : looking for the string
     * 3 : just reached the string
     * 4 : looking for closing parenthesis
     */
    var inRequireState = -1;
    var inRequireBeginString;
    var inRequireEndString;

    for (var l = array.length; i < l && i >= 0; i++) {
        var curItem = array[i];
        var firstChar = curItem.charAt(0);
        if (firstChar == '/') {
            // it may be a comment, a division or a regular expression
            if (curItem == '/' && i + 1 < l && array[i + 1].charAt(0) == '/') {
                i = findEndOfSlashComment(array, i);
                l = array.length; // when processing comments, the array is changed
            } else if (curItem.charAt(1) == "*") {
                i = findEndOfStarComment(array, i);
                l = array.length; // when processing comments, the array is changed
            } else if (isRegExp(array, i)) {
                i = findEndOfStringOrRegExp(array, i);
            }
        } else if (quoteRegExp.test(firstChar)) {
            inRequireBeginString = i;
            i = findEndOfStringOrRegExp(array, i);
            if (inRequireState == 2) {
                inRequireState = 3;
                inRequireEndString = i;
            }
        } else if (firstChar == "r") {
            if (requireRegExp.test(curItem) && checkRequireScope(array, i)) {
                inRequireState = 1;
            }
        }
        if (inRequireState > 0) {
            if (inRequireState == 1) {
                inRequireState = 2;
            } else {
                curItem = array[i];
                if (inRequireState == 3) {
                    curItem = curItem.substring(1);
                    inRequireState = 4;
                }
                if (firstNonSpaceCharRegExp.test(curItem)) {
                    if (inRequireState == 4 && RegExp.$1 == ")") {
                        ids.push(getStringContent(array, inRequireBeginString, inRequireEndString));
                    }
                    inRequireState = 0;
                }
            }
        }
    }
    // Here, array.join('') should exactly contain the source but without comments.
    return ids;
};


});

internalDefine(6 /* jsEval */, function (module) {

var exec = internalRequire(18 /* eval */);
var noderError = internalRequire(12 /* noderError */);

module.exports = function(jsCode, url, lineDiff) {
    try {
        return exec(jsCode, url);
    } catch (error) {
        throw noderError("jsEval", [jsCode, url, lineDiff], error);
    }
};


});

internalDefine(7 /* request */, function (module) {

var promise = internalRequire(4 /* promise */);
var noderError = internalRequire(12 /* noderError */);
var HttpRequestObject = global.XMLHttpRequest;
var newHttpRequestObject;

if (HttpRequestObject) {
    newHttpRequestObject = function() {
        return new HttpRequestObject();
    };
} else {
    HttpRequestObject = global.ActiveXObject;
    newHttpRequestObject = function() {
        return new HttpRequestObject("Microsoft.XMLHTTP");
    };
}

var createCallback = function(url, xhr, deferred) {
    return function() {
        if (xhr && xhr.readyState == 4) {
            var error = (xhr.status != 200);
            if (error) {
                deferred.reject(noderError('XMLHttpRequest', [url, xhr]));
            } else {
                deferred.resolve(xhr.responseText, xhr);
            }
            // clean the closure:
            url = xhr = deferred = null;
        }
    };
};

module.exports = function(url, options) {
    options = options || {};
    var deferred = promise();
    var xhr = newHttpRequestObject();
    var headers = options.headers || {};
    for (var key in headers) {
        if (headers.hasOwnProperty(key)) {
            xhr.setRequestHeader(key, headers[key]);
        }
    }
    xhr.open(options.method || 'GET', url, true);
    xhr.onreadystatechange = createCallback(url, xhr, deferred);
    // Note that, on IE, onreadystatechange can be called during the call to send
    xhr.send(options.data);
    return deferred.promise();
};


});

internalDefine(8 /* loader */, function (module) {

var request = internalRequire(7 /* request */);
var jsEval = internalRequire(6 /* jsEval */);
var findInMap = internalRequire(19 /* findInMap */);
var defaultBaseUrl = internalRequire(20 /* defaultBaseUrl */);
var split = internalRequire(13 /* path */).split;
var emptyObject = {};

var Loader = function(context) {
    var config = context.config.packaging || emptyObject;
    this.config = config;
    this.baseUrl = ("baseUrl" in config) ? config.baseUrl : defaultBaseUrl();
    this.context = context;
    this.currentLoads = {};
    var bootstrap = config.bootstrap;
    if (bootstrap) {
        bootstrap(context.define);
    }
};

var loaderProto = Loader.prototype = {};

loaderProto.moduleLoad = function(module) {
    var moduleName = module.filename;
    var packageName;
    var packagesMap = this.config.packagesMap;
    if (packagesMap) {
        var splitModuleName = split(moduleName);
        packageName = findInMap(packagesMap || emptyObject, splitModuleName, null);
    }
    if (packageName) {
        return this.loadPackaged(packageName);
    } else {
        return this.loadUnpackaged(moduleName);
    }
};

loaderProto.loadUnpackaged = function(moduleName) {
    var url = this.baseUrl + moduleName;
    var context = this.context;
    return request(url).then(function(jsCode) {
        context.jsModuleDefine(jsCode, moduleName, url);
    }).always(function() {
        context = null;
    });
};

loaderProto.loadPackaged = function(packageName) {
    var self = this;
    var url = self.baseUrl + packageName;
    var res = self.currentLoads[url];
    if (!res) {
        self.currentLoads[url] = res = request(url).then(function(jsCode) {
            var body = self.jsPackageEval(jsCode, url);
            body(self.context.define);
        }).always(function() {
            delete self.currentLoads[url];
            self = null;
        });
    }
    return res;
};

loaderProto.jsPackageEval = function(jsCode, url) {
    var code = ['(function(define){\n', jsCode, '\n})'];
    return jsEval(code.join(''), url, 1 /* we are adding 1 line compared to url */ );
};

module.exports = Loader;


});

internalDefine(9 /* resolver */, function (module) {

var noderError = internalRequire(12 /* noderError */);
var path = internalRequire(13 /* path */);
var isString = internalRequire(11 /* type */).isString;
var split = path.split;
var emptyObject = {};

var addExtension = function(pathArray) {
    var index = pathArray.length - 1;
    var lastItem = pathArray[index];
    if (lastItem.indexOf('.') == -1) {
        pathArray[index] = lastItem + '.js';
    }
};

var normalize = function(pathArray) {
    for (var i = 0, l = pathArray.length; i < l; i++) {
        var currentPart = pathArray[i];
        if (!currentPart.length || currentPart == '.') {
            pathArray.splice(i, 1);
            i--;
            l--;
        } else if (currentPart == '..' && i > 0 && pathArray[i - 1] != '..') {
            pathArray.splice(i - 1, 2);
            i -= 2;
            l -= 2;
        }
    }
    return pathArray;
};

var applyChange = function(terms, item, index) {
    var itemParts = split(item);
    if (!itemParts[0].length) {
        // item starts with /, replaces the whole terms
        itemParts.shift();
        itemParts.unshift(0, index + 1);
    } else {
        // item is relative
        itemParts.unshift(index, 1);
    }
    terms.splice.apply(terms, itemParts);
};

/**
 * Apply a module map iteration.
 * @param {Object} map
 * @param {Array} terms Note that this array is changed by this function.
 * @return {Boolean}
 */
var applyModuleMap = function(map, terms) {
    for (var i = 0, l = terms.length; i < l; i++) {
        var curTerm = terms[i];
        map = map[curTerm];
        if (!map || curTerm === map) {
            return false; // no change
        } else if (isString(map)) {
            applyChange(terms, map, i);
            return true;
        }
    }
    // if we reach this place, it is a directory
    applyChange(terms, map['.'] || "index.js", terms.length);
    return true;
};

var multipleApplyModuleMap = function(map, terms) {
    var allValues = {};
    // curValue can never be equal to ".", as it is always assigned after normalizing
    var lastValue = ".";
    normalize(terms);
    var curValue = terms.join('/');
    while (curValue !== lastValue) {
        if (terms[0] == '..') {
            throw noderError('resolverRoot', [terms]);
        }
        if (allValues[curValue]) {
            throw noderError('resolverLoop', [terms]);
        } else {
            allValues[curValue] = lastValue;
        }
        if (applyModuleMap(map, terms)) {
            normalize(terms);
        }
        lastValue = curValue;
        curValue = terms.join('/');
    }
};

var Resolver = function(context) {
    this.config = context.config.resolver || emptyObject;
    this.cache = {};
};
var resolverProto = Resolver.prototype = {};

resolverProto.moduleResolve = function(callerModule, calledModule) {
    // Compute the configuration to apply to the caller module:
    var callerModuleSplit = split(callerModule.filename);
    var moduleMap = this.config['default'] || emptyObject;
    var res = split(calledModule);
    var firstPart = res[0];
    if (firstPart === '.' || firstPart === '..') {
        callerModuleSplit.pop(); // keep only the directory
        res = callerModuleSplit.concat(res);
    }

    multipleApplyModuleMap(moduleMap, res);
    addExtension(res);
    return res.join('/');
};

module.exports = Resolver;


});

internalDefine(10 /* execScripts */, function (module) {

var promise = internalRequire(4 /* promise */);
var uncaughtError = internalRequire(17 /* uncaughtError */);
var domReady = internalRequire(21 /* domReady */);

var createModuleExecuteFunction = function(context, module) {
    return function() {
        // calling .end() here allows to go on with the execution of script tags
        // even if one has an execution error, and makes sure the error is reported
        // on the console of the browser
        return context.moduleExecute(module).end();
    };
};

module.exports = function(context, scriptType) {
    return domReady().then(function() {
        var scripts = global.document.getElementsByTagName('script');
        var executePromise = promise.done;
        var i, l;
        for (i = 0, l = scripts.length; i < l; i++) {
            var curScript = scripts[i];
            if (curScript.type === scriptType) {
                var filename = curScript.getAttribute('data-filename');
                // the try ... catch here allows to go on with the execution of script tags
                // even if one has a syntax error
                try {
                    // all scripts are defined before any is executed
                    // so that it is possible to require one script tag from another (in any order)
                    var curModule = context.jsModuleDefine(curScript.innerHTML, filename);
                    executePromise = executePromise.then(createModuleExecuteFunction(context, curModule));
                } catch (error) {
                    uncaughtError(error);
                }
            }
        }
        return executePromise;
    }).end();
};


});

internalDefine(11 /* type */, function (module) {

var toString = Object.prototype.toString;
var isString = function(str) {
    return (typeof str === "string") || toString.call(str) === '[object String]';
};
var isArray = Array.isArray || function(obj) {
        return toString.call(obj) === '[object Array]';
    };

var isFunction = function(fn) {
    return (typeof fn == "function");
};

var isPlainObject = function(obj) {
    return obj ? toString.call(obj) === '[object Object]' : false;
};

module.exports = {
    isFunction: isFunction,
    isArray: isArray,
    isString: isString,
    isPlainObject: isPlainObject
};


});

internalDefine(12 /* noderError */, function (module) {

var errorNb = 0;

var syncLogDetails;
var asyncLogDetails = function() {
    var self = this;
    if (syncLogDetails) {
        return syncLogDetails.call(self);
    }
    return getHandler().then(function() {
        return syncLogDetails.call(self, true);
    });
};

var handlerPromise;
var getHandler = function() {
    if (!handlerPromise) {
        var Context = internalRequire(2 /* context */);
        var loadingContext = new Context();
        handlerPromise = loadingContext.moduleExecute(loadingContext.getModule("noderError/error.js")).then(function(
            receivedHandler) {
            // changes the logDetails function for next time
            syncLogDetails = receivedHandler;
        });
    }
    return handlerPromise;
};

var createError = function(code, args, cause) {
    var id = ++errorNb;
    var error = new Error("NoderError #" + id + ": " + code);
    error.name = "NoderError";
    error.id = id;
    error.code = code;
    error.args = args;
    error.cause = cause;
    error.logDetails = syncLogDetails || asyncLogDetails;
    return error;
};

module.exports = createError;


});

internalDefine(13 /* path */, function (module) {

var split = function(name) {
    if (!name.length) {
        return [];
    } else {
        return name.split("/");
    }
};

var dirname = function(name) {
    var array = split(name);
    array.pop();
    return array.join('/');
};

module.exports = {
    split: split,
    dirname: dirname
};


});

internalDefine(14 /* scriptConfig */, function (module) {

var scriptTag = internalRequire(22 /* scriptTag */);
var config = {};
var configContent = scriptTag.innerHTML;
if (!/^\s*$/.test(configContent || "")) {
    var exec = internalRequire(18 /* eval */);
    config = exec(configContent) || config;
}
var src = scriptTag.src;
if (!config.main && src) {
    var questionMark = src.indexOf('?');
    if (questionMark > -1) {
        config.main = decodeURIComponent(src.substring(questionMark + 1));
    }
}

module.exports = config;


});

internalDefine(15 /* extend */, function (module) {

module.exports = function(dst, src) {
    for (var key in src) {
        if (src.hasOwnProperty(key)) {
            dst[key] = src[key];
        }
    }
    return dst;
};


});

internalDefine(16 /* callListeners */, function (module) {

var nextTick = internalRequire(23 /* nextTick */);
var uncaughtError = internalRequire(17 /* uncaughtError */);

module.exports = function(listeners, result) {
    if (listeners && listeners.length) {
        nextTick(function() {
            for (var i = 0, l = listeners.length; i < l; i++) {
                var curItem = listeners[i];
                try {
                    curItem.apply(null, result);
                } catch (e) {
                    uncaughtError(e);
                }
            }
            listeners = null;
            result = null;
        });
    }
};


});

internalDefine(17 /* uncaughtError */, function (module) {

var nextTick = internalRequire(23 /* nextTick */);

module.exports = function(e) {
    nextTick(function() {
        if (e.logDetails) {
            e.logDetails();
        }
        throw e;
    });
};


});

internalDefine(18 /* eval */, function (module) {

var appendSourceUrl = true;

module.exports = function(code, fileName) {
    var res = {};
    // Using the 'arguments[1].res = ...' trick because IE does not let eval return a function
    if (fileName && appendSourceUrl) {
        code = ['/*\n * File: ', fileName, '\n */\narguments[1].res=', code, '\n//@ sourceURL=', fileName].join('');
    } else {
        code = 'arguments[1].res=' + code;
    }
    callEval(code, res); // callEval is defined outside of any closure
    return res.res;
};


});

internalDefine(19 /* findInMap */, function (module) {

var isPlainObject = internalRequire(11 /* type */).isPlainObject;

module.exports = function(map, terms, defaultValue) {
    if (!map) {
        return defaultValue;
    }
    defaultValue = map['**'] || defaultValue;
    for (var i = 0, l = terms.length; i < l; i++) {
        var curTerm = terms[i];
        var value = map[curTerm];
        if (!value) {
            return map['*'] || map['**'] || defaultValue;
        } else if (!isPlainObject(value)) {
            return value;
        }
        defaultValue = map['**'] || defaultValue;
        map = value;
    }
    return map['.'] || map['*'] || map['**'] || defaultValue;
};


});

internalDefine(20 /* defaultBaseUrl */, function (module) {

module.exports = function() {
    var src = internalRequire(22 /* scriptTag */).src;
    return src ? internalRequire(13 /* path */).dirname(src.replace(/\?.*$/, '')) + "/" : "";
};


});

internalDefine(21 /* domReady */, function (module) {

var promise = internalRequire(4 /* promise */);
var domReadyPromise;
var createDomReadyPromise = function() {
    var document = global.document;
    if (document && document.readyState === "complete") {
        // in this simple case, avoid creating a new promise, just use promise.done
        return promise.done;
    }
    var res = promise();
    if (!document) {
        // this may happen, for example, in a web worker
        res.reject(new Error("No document."));
    } else {
        var callback = function() {
            if (res) {
                res.resolve(); // resolve with no parameter
            }
        };
        if (document.addEventListener) {
            document.addEventListener("DOMContentLoaded", callback);
            // Fallback in case the browser does not support DOMContentLoaded:
            global.addEventListener("load", callback);
            res.always(function() {
                // clean the closure and listeners
                document.removeEventListener("DOMContentLoaded", callback);
                global.removeEventListener("load", callback);
                document = null;
                callback = null;
                res = null;
            });
        } else if (document.attachEvent) {
            // Fallback to the onload event on IE:
            global.attachEvent("onload", callback);
            res.always(function() {
                // clean the closure and listeners
                global.detachEvent("onload", callback);
                document = null;
                callback = null;
                res = null;
            });
        }
    }
    return res.promise();
};

module.exports = function() {
    if (!domReadyPromise) {
        domReadyPromise = createDomReadyPromise();
    }
    return domReadyPromise;
};


});

internalDefine(22 /* scriptTag */, function (module) {

var document = global.document;
var scriptTag;
// When not in the loading mode, it is not reliable to use the last script to find the configuration
if (document.readyState == "loading") {
    var scripts = document.getElementsByTagName('script');
    scriptTag = scripts[scripts.length - 1];
    if (scriptTag && !scriptTag.src) {
        // without src it cannot be the right script tag
        scriptTag = null;
    }
}

module.exports = scriptTag || {}; // must not be null


});

internalDefine(23 /* nextTick */, function (module) {

var setTimeout = global.setTimeout;
module.exports = function(fn) {
    setTimeout(fn, 0);
};


});

return internalRequire(1);
})((function(){return this;})(),function(c){
/*jshint evil:true */
eval(c);
});